$ = function(_id) {
  return document.getElementById(_id);
}
_bind = function(func, that) {
  return function() {
    func.call(that)
  }
}

class TodoView {
  constructor(myList, finishedListView) {
    this.myList = myList;
    this.todoListView = $("list-content");
    this.finishedListView = $("finished-list-content");
    this.todoView = $("todo-view");
    this.finishedView = $("finished-view");
    this.todoInput = $("input-content");  
    
    for (var i = 0; i < myList.list.length; i++) {
      var item = myList.list[i];
      if (item.pending) {
        this.todoListView.appendChild(todoDomItem(item));
      } else {
        this.finishedListView.appendChild(todoDomItem(item));
      }
    }
    this.toggleView();
    this.bind();
  }
  
  bind() {
    $("button-add-item").addEventListener('click', () => this.addBtnListner());
    $("button-return").addEventListener('click', () => this.toggleView());
    $("button-view-finished").addEventListener('click', () => this.toggleView());
    $("input-content").addEventListener('keydown', e => this.handleKeyDownListner(e));
  }

  toggleView() {
    let isTodo = this._state === 'todo';
    this.todoView.className = isTodo ? 'hidden' : '';
    this.finishedView.className = isTodo ? '' : 'hidden';
    this._state = isTodo ? 'finished' : 'todo';
  }

  handleKeyDownListner(e) {
    if (e.which === 13) {
      this.addBtnListner();
    }
  }

  addBtnListner() {
    var content = this.todoInput.value;
    if (content.length == 0) {
      alert('NOTHING TO ADD.');
    } else{
      var item = this.myList.addTask(item);
      var domItem = todoDomItem(item);
      this.todoListView.appendChild(domItem);
      this.todoInput.value = '';
    }
  }
}
