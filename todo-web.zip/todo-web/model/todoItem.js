class TodoItem {
  constructor({ content, pending, birth }, container) {
    this.content = content;
    this.pending = pending === undefined ? true : pending;
    this.birth = birth || timeStamp();
    this.container = container;
  }

  finish() {
    this.pending = false;
    this.container.saveToLS();
  }
  
  remove() {
    if (this.container.list.indexOf(this) != -1) {
      this.container.list.splice(this.container.list.indexOf(this), 1);
    }
    this.container.saveToLS();
  }

  setDomNode(domNode) {
    this.domNode = domNode;
  }
}
