class TodoList {
  constructor(name) {
    this.name = name;
    this.list = [];
  }

  addTask(content) {
    let item = new TodoItem({ content }, this);
    this.list.push(item);
    this.saveToLS();
    return item;
  }

  loadFromLS() {
    let plainList = JSON.parse(localStorage.getItem(this.name) || '[]');
    this.list = plainList.map(e => {
      let item = new TodoItem(e, this);
      return item;
    });
  }

  saveToLS() {
    let plainList = [];

    for (let i = 0; i < this.list.length; i++){
      let { content, pending, birth } = this.list[i];
      plainList.push({ content, pending, birth });
    }

    localStorage.setItem(this.name, JSON.stringify(plainList));
  }
}
